import os
import re

import pytest

from assistant.app import build_service
from assistant.data.database import Database
from assistant.data.lookups import existing_tables
from assistant.settings import Settings

CONNECTION_STRING = os.getenv("SQLSERVER_CONNECTION_STRING")
pytestmark = pytest.mark.skipif(
    not CONNECTION_STRING, reason="Set SQLSERVER_CONNECTION_STRING to run SQL Server checks"
)


def test_readonly_sql_server_connection_and_schema():
    with Database(CONNECTION_STRING).cursor() as cursor:
        cursor.execute("SELECT DB_NAME() AS database_name")
        assert cursor.fetchone()["database_name"]
        required = {"assets", "locations", "employees"}
        actual = existing_tables(cursor, {"Assets", "Locations", "Employees"})
        assert required <= actual


def test_available_prompt_matches_storage_rule():
    service = build_service(Settings(connection_string=CONNECTION_STRING, classifier="rules"))
    with Database(CONNECTION_STRING).cursor() as cursor:
        cursor.execute(
            "SELECT COUNT_BIG(*) AS value FROM dbo.Assets "
            "WHERE AssetType = 'Laptop' AND EmployeeId IS NULL AND StoreroomId IS NOT NULL"
        )
        expected = int(cursor.fetchone()["value"])
    reply = service.ask("How many laptops are available?")
    assert reply["scope"] == "in"
    assert reply["intent"] == "count_assets"
    match = re.search(r"\*\*(\d+)\b", reply["answer"])
    assert match and int(match.group(1)) == expected
