from pathlib import Path

from assistant.catalog import load_catalog, validate_catalog
from assistant.data.lookups import available_intents
from assistant.queries.runner import QueryRunner


def test_test_schema_prompts_have_fixed_queries_or_handlers():
    catalog = load_catalog()
    validate_catalog(catalog)
    test_schema = {
        "assets", "employees", "departments", "locations", "storerooms",
        "assetassignments", "assethistory", "assettransfers",
    }
    available = available_intents(test_schema, catalog)
    runner = QueryRunner(catalog)
    handlers = {"show_chart", "list_dashboards", "open_dashboard"}
    assert available
    assert all(name in runner._sql or name in handlers for name in available)


def test_missing_case_tables_keep_dependent_prompts_unavailable():
    catalog = load_catalog()
    available = available_intents({"assets", "employees", "departments", "locations"}, catalog)
    assert "maintenance_open" not in available
    assert "overdue_confirmations" not in available
    assert "aod_cases" not in available
    assert "open_loss_cases" not in available


def test_available_means_unassigned_and_in_storeroom():
    sql = (Path(__file__).parents[2] / "assistant/sqlserver/_filters.sql").read_text()
    assert "a.EmployeeId IS NULL AND a.StoreroomId IS NOT NULL" in sql
