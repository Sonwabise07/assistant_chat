from io import BytesIO
from zipfile import ZipFile

from assistant.exports import build_report

REPLY = {
    "answer": "**1 asset** matches.",
    "source": "Based on Asset register data.",
    "table": {
        "columns": ["asset_no", "description"],
        "rows": [{"asset_no": "AST-1", "description": "Laptop"}],
    },
}


def test_excel_export_is_a_workbook_and_escapes_formula_cells():
    contents, media_type, extension = build_report(REPLY, "=1+1", "xlsx")
    assert media_type.endswith("spreadsheetml.sheet")
    assert extension == "xlsx"
    with ZipFile(BytesIO(contents)) as archive:
        assert "xl/workbook.xml" in archive.namelist()
        sheet = archive.read("xl/worksheets/sheet1.xml").decode()
        assert "'=1+1" in sheet


def test_word_export_is_a_document():
    contents, media_type, extension = build_report(REPLY, "Show assets", "docx")
    assert media_type.endswith("wordprocessingml.document")
    assert extension == "docx"
    with ZipFile(BytesIO(contents)) as archive:
        assert "word/document.xml" in archive.namelist()


def test_empty_result_cannot_be_exported_as_a_data_table():
    reply = {**REPLY, "table": None}
    try:
        build_report(reply, "No results", "xlsx")
    except ValueError as error:
        assert "no tabular results" in str(error).lower()
    else:
        raise AssertionError("Expected an empty result to be rejected")