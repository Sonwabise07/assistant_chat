from assistant.data.database import CursorAdapter


class FakeCursor:
    def __init__(self):
        self.executed = None
        self.description = [("value",)]

    def execute(self, query, params=()):
        self.executed = (query, list(params) if params is not None else [])
        return self

    def fetchone(self):
        return (1,)

    def fetchall(self):
        return [(1,), (2,)]


def test_named_parameters_are_bound_in_occurrence_order():
    raw = FakeCursor()
    cursor = CursorAdapter(raw)
    cursor.execute("SELECT %(x)s + %(y)s + %(x)s", {"x": 4, "y": 2})
    assert raw.executed == ("SELECT ? + ? + ?", [4, 2, 4])


def test_results_are_dictionary_rows():
    cursor = CursorAdapter(FakeCursor())
    assert cursor.fetchone() == {"value": 1}
    assert cursor.fetchall() == [{"value": 1}, {"value": 2}]
