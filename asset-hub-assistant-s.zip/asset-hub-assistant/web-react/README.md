# Asset Hub Data Assistant: React screen

The chat, charts and dashboards for the Data Assistant, built with React and TypeScript.
No UI library and no chart library: the charts are small SVG and HTML components styled with the Asset Hub colours.

## Run it
Needs Node 20 or newer and the assistant backend running on port 8000 (`python -m assistant` in the project folder).
```
cd web-react
npm ci
npm run dev          # http://localhost:5173
```
The dev server forwards `/api` to `http://localhost:8000`, so no extra setup is needed.
The standalone prototype has no role or actor selector. "My assets" uses the configured local demo identity. In the integrated system, the API must derive identity from the authenticated session/token; do not trust client-supplied identity or scope as authorization.

| Command | Does |
|---|---|
| `npm run dev` | Development server with live reload |
| `npm test` | Vitest and Testing Library suite |
| `npm run typecheck` | TypeScript check |
| `npm run build` | Type check, then a production build in `dist/` |
| `npm run format` | Prettier |

## What is in it
```
src/
  api/types.ts          the API shapes (keep in step with the API contract in the main README)
  api/client.ts         fetch calls. The only file that talks to the network
  components/
    charts/             BarList (groups), ColumnChart (over time), ChartView (picks one)
    widgets/            one component per widget type, and WidgetRenderer that picks by type
    dashboard/          DashboardView: the widget grid
    chat/               ChatPanel, useChat, message components, SupportedTypes
    DataTable.tsx, Icon.tsx
  shell/ and pages/     PROTOTYPE ONLY: sidebar, header, hash routing and the three pages
  styles/tokens.css     the design colours as CSS variables
  test/                 fixtures captured from the real backend, and a fetch mock
```

## How it fits together
- `useChat` keeps the conversation and sends the previous question type with each question, so follow-ups such as "and laptops?" and "show this as a chart" work. Social replies and refusals do not overwrite that data context.
- The **Questions I can ask** selector is collapsed by default. It loads categories, example prompts, and availability from `GET /api/assistant/meta`; selecting an available prompt puts it in the composer so the user can review or edit it before sending.
- A chat reply can carry text, a chart, a table, a facts card (an asset) and a whole dashboard. `AssistantMessage` draws each part that is present.
- Dashboard choices come back as suggestion buttons. Clicking one asks "Open the ... dashboard".
- `WidgetRenderer` draws a dashboard widget by its `type`. A widget whose tables do not exist yet shows a plain note.
- Charts: one colour, because position and length carry the meaning. `ColumnChart` labels only the highest column and every other month when there are many. Hover shows each value.

## Moving into the main React app
Copy these:
- `src/components/` (the whole folder), `src/api/types.ts`, `src/utils/`
- `src/styles/tokens.css`, and map the variables to the main theme. The components only use these variables.

Replace these:
- `src/api/client.ts`: use the main app's HTTP layer so requests carry the login token. The API should derive the signed-in user's identity from that authenticated context for personal shortcuts; do not send identity or data scope as client authority.

Do not copy:
- `src/shell/` and `src/pages/`: they are a stand-in for the main app's layout and router. From them, reuse `DashboardBody`, `FloatingChat` and the way `ChatPanel` and `SupportedTypes` are placed in `AssistantPage`.
- Wire `onOpenDashboard` to the main router. The prototype sends Overview to Dashboard and Operational and Management to the Reports tabs (`routeForDashboard`).

Styles are plain CSS files next to each component, with class names like `chat__input` and `kpi-card`. If the main app uses CSS modules or another system, port them component by component.

The CtrlFind mobile client is Expo/React Native, not a DOM React app. Use this web screen as a behavior and API-contract reference, then implement the prompt selector and chat components with native controls. Do not place browser-only elements such as `<details>` or DOM CSS into the React Native screen.

## Known limits
- The Python backend is still the prototype. The screens currently use its API contract; they will need a client adapter and contract mapping before they can work with the .NET API.
- The sidebar shows the full menu from the designs, but only Dashboard, Reports and Data assistant are pages so far.
- Fixtures in `src/test/fixtures/` are saved backend replies. Refresh them if the API changes.
