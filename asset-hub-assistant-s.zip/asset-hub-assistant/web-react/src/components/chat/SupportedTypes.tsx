import type { Meta } from '../../api/types';
import './chat.css';

/** A compact, keyboard-accessible prompt picker. Unavailable examples stay visible but disabled. */
export function SupportedTypes({
  categories,
  onSelect,
}: {
  categories: Meta['categories'];
  onSelect: (prompt: string) => void;
}) {
  const availableCount = categories.reduce(
    (total, category) =>
      total + category.questions.filter((question) => question.available).length,
    0,
  );

  return (
    <details className="supported">
      <summary className="supported__summary">
        <span>
          <strong>Questions I can ask</strong>
          <small>Pick an example to add it to your message.</small>
        </span>
        <span className="supported__count">{availableCount} available</span>
      </summary>
      <div className="supported__content">
        {categories.map((category) => (
          <details className="supported__category" key={category.label}>
            <summary>
              <span>{category.label}</span>
              <span className={category.available ? 'supported__availability' : 'supported__availability supported__availability--off'}>
                {category.available ? 'Available' : 'Not available'}
              </span>
            </summary>
            <ul>
              {category.questions.map((question, index) => (
                <li key={`${question.intent}-${index}`}>
                  <button
                    type="button"
                    className="supported__prompt"
                    disabled={!question.available}
                    aria-label={`Use example question: ${question.prompt}`}
                    onClick={() => onSelect(question.prompt)}
                  >
                    {question.prompt}
                  </button>
                  {!question.available && (
                    <small>Required data is not available in this database yet.</small>
                  )}
                </li>
              ))}
            </ul>
          </details>
        ))}
        <p className="supported__note">
          Examples show supported question types. Availability depends on the configured database.
          This standalone prototype currently uses a shared data scope.
        </p>
      </div>
    </details>
  );
}
