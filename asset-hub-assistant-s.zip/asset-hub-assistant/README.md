# Asset Hub Data Assistant — SQL Server test build

A standalone, read-only assistant for testing against a **synthetic SQL Server database** shaped after the supplied CtrlFind API's EF Core model. This package is a pre-integration test build: it does not call the .NET API, use production credentials, or enforce production user permissions.

The assistant routes questions to fixed, parameterized T-SQL templates. It does not let a language model generate SQL. Set `CLASSIFIER=rules` for deterministic local testing; Ollama is optional and only helps classify questions.

## What this build supports

Availability is derived from tables present in the connected database and exposed by `GET /api/assistant/meta`. With the included test schema, the mapped capabilities are asset counts, asset breakdowns/charts, filtered asset lists, warranty windows, purchase-spend comparisons, location coverage, rankings, purchases by date, laptop age, assignment history, asset history, inactive-employee asset checks, and personal/team asset queries for the configured test identity.

The original prompt regression corpus remains at `tests/prompts.json` (125 prompts, including refusal and edge-case examples). Prompts that need audit confirmations, AOD/loss cases, maintenance records, dashboards, or other unmapped tables are deliberately shown as unavailable. Do not interpret an unavailable prompt as a successful feature.

**Available asset definition for this test:** an asset is available only when `EmployeeId IS NULL` and `StoreroomId IS NOT NULL`. `OperationalStatus` alone does not make an asset available.

## Requirements

- Python 3.10+
- Microsoft ODBC Driver 18 for SQL Server installed on the test machine
- SQL Server 2017 or newer (the query templates use `CONCAT_WS`)
- Access to a **non-production** SQL Server instance
- Node.js 20+ only if running the optional React web client
- Optional: Ollama for model-assisted classification; rules mode does not need it

## Create a synthetic test database

From the repository root, run the included test-only schema and seed script using `sqlcmd`:

```powershell
sqlcmd -S localhost -E -d master -i db/sqlserver-test-schema.sql
```

For SQL authentication, use your local test account instead of `-E` (for example `-U <test-user>`); `sqlcmd` will prompt for its password. This script creates `AssetHubAssistantTest`, drops/recreates only its test tables, and inserts synthetic records. **Never point it at production.**

The script follows the supplied CtrlFind model's core tables: `Assets`, `Employees`, `Departments`, `Locations`, `Storerooms`, `AssetAssignments`, `AssetHistory`, and `AssetTransfers`. It is a test fixture, not a migration for the larger application. The assistant itself only needs read access; an example least-privilege role is in `db/sqlserver-roles.sql`.

## Configure and run the assistant

Create a virtual environment and install dependencies:

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python -m pip install -r requirements-dev.txt
```

Set a local ODBC connection string; do not commit it. For Windows integrated authentication:

```powershell
$env:SQLSERVER_CONNECTION_STRING = 'Driver={ODBC Driver 18 for SQL Server};Server=localhost;Database=AssetHubAssistantTest;Trusted_Connection=yes;TrustServerCertificate=yes;'
$env:CLASSIFIER = 'rules'
$env:ASSISTANT_DEMO_EMAIL = 'test.employee@example.invalid'
python -m assistant
```

For SQL authentication, use a dedicated read-only test login and keep its password in your local environment or secret manager:

```powershell
$env:SQLSERVER_CONNECTION_STRING = 'Driver={ODBC Driver 18 for SQL Server};Server=localhost;Database=AssetHubAssistantTest;UID=<test-user>;PWD=<test-password>;Encrypt=yes;TrustServerCertificate=yes;'
```

The API binds to `127.0.0.1:8000` by default. Keep it local for testing; it has no production authentication. Open <http://localhost:8000> for the original web UI. The optional React client can be started with `cd web-react`, `npm ci`, then `npm run dev` in another terminal.

## Test prompts and QA

Useful prompts supported by the included test schema:

- “How many laptops are available?”
- “How many assets are registered?”
- “Show assets by status.”
- “Show me the available monitors.”
- “Which assets go out of warranty in the next 90 days?”
- “Compare purchase spend this month and last month.”
- “How many locations do we have?”
- “Which location has the most laptops?”
- “What did we buy in the last 90 days?”
- “How old are our laptops?”
- “What does Test Employee have?” / “What am I responsible for?” (set `ASSISTANT_DEMO_EMAIL` to a matching synthetic employee)
- “Show the history of AST-000002.”
- “Which assets were assigned to Test Employee in February 2024?”
- “Show my team's assets.” (uses the test user's department)
- “Which assets are still held by people who have left?” (the synthetic fixture includes an inactive employee with an assigned asset)

Run checks:

```powershell
pytest tests/unit
pytest tests/integration/test_sqlserver_smoke.py
python tests/try_prompts.py
python tests/try_prompts.py --group refused
```

The SQL Server smoke tests skip unless `SQLSERVER_CONNECTION_STRING` is set. Run web checks with `cd web-react`, then `npm test`, `npm run typecheck`, and `npm run build`.

The prompt selector and metadata endpoint are authoritative for which prompts are currently available against the connected schema. Check answers against the synthetic rows; also test empty results, ambiguous/unsupported wording, date boundaries, invalid input, timeouts, and large result sets before calling the standalone test gate complete. Test a chart-producing breakdown, a returned table, a follow-up, and an XLSX/DOCX export for supported list questions. Dashboard widgets are intentionally unavailable in this build.

The standalone HTTP contract remains:

- `GET /api/assistant/meta` — categories, example prompts, and per-intent availability.
- `POST /api/assistant/ask` — JSON `{ "question": "How many laptops are available?", "context": null }`.
- Follow-ups may send the prior in-scope `intent` and `slots` in `context`; this is conversational context only, never identity or authorization.
- `POST /api/assistant/export` — JSON `{ "question": "Show me the available monitors", "context": null, "format": "xlsx" }`; `format` can be `xlsx` or `docx`, and exports are capped at 5,000 rows.
- Dashboard routes are retained for API compatibility but return no configured dashboards until dashboard SQL is mapped to the target schema.

## Pre-integration boundary and known gaps

The supplied mobile app currently has a placeholder Data Assistant screen. The .NET `POST /api/v1/assistant/query` endpoint in the supplied API archive is a demo controller over an in-memory store, not a SQL Server-backed chatbot integration. This Python service intentionally runs independently for pre-integration testing.

- No production sign-in, authorization, or per-user row-level security is provided. The demo identity is only for personal shortcuts; it is not an access boundary. Use synthetic data and keep the server local.
- Do not trust client-provided department/location filters as authorization. The integrated .NET path must derive identity and data scope from the authenticated request on the server.
- The test SQL is read-only from the assistant's perspective. `db/sqlserver-roles.sql` grants SELECT only; read-only access does not itself restrict which rows a user can see.
- Audits, overdue confirmations, maintenance case data, AOD, loss/theft cases, and dashboard widgets are not represented in the supplied core SQL Server schema and are marked unavailable.
- The API request/response envelope and authenticated .NET flow still require a separately agreed adapter and end-to-end tests. This build does not certify those integration behaviors.

## Configuration

| Variable | Purpose | Default |
|---|---|---|
| `SQLSERVER_CONNECTION_STRING` | ODBC connection to the non-production test database | Required |
| `ASSISTANT_DEMO_EMAIL` | Synthetic employee used by personal shortcuts | Empty / guest |
| `CLASSIFIER` | `rules`, `ollama`, or `auto` | `rules` |
| `OLLAMA_URL` | Local Ollama endpoint | `http://localhost:11434` |
| `OLLAMA_MODEL` | Local model name | `llama3.2:3b` |
| `PORT` | Local HTTP port | `8000` |

Keep connection strings, passwords, tokens, and production data out of source control and test fixtures.
