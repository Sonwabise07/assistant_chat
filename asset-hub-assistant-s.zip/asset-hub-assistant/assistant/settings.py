import os
from dataclasses import dataclass


@dataclass(frozen=True)
class Settings:
    connection_string: str = ""
    ollama_url: str = "http://localhost:11434"
    ollama_model: str = "llama3.2:3b"
    classifier: str = "rules"
    port: int = 8000
    demo_email: str = ""

    @classmethod
    def from_env(cls) -> "Settings":
        env = os.environ.get
        return cls(
            connection_string=env("SQLSERVER_CONNECTION_STRING", ""),
            ollama_url=env("OLLAMA_URL", cls.ollama_url),
            ollama_model=env("OLLAMA_MODEL", cls.ollama_model),
            classifier=env("CLASSIFIER", cls.classifier),
            port=int(env("PORT", cls.port)),
            demo_email=env("ASSISTANT_DEMO_EMAIL", ""),
        )

