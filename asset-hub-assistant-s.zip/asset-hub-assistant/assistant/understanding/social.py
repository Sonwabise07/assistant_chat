"""Small deterministic replies for greetings and common conversational messages."""

import re

_NORMALISE = re.compile(r"\s+")
_TRAILING_PUNCTUATION = re.compile(r"[.!?,;:]+$")

_PATTERNS = (
    (
        "greeting",
        re.compile(
            r"^(?:hi|hello|hey|good morning|good afternoon|good evening)(?: there)?$",
            re.IGNORECASE,
        ),
        (
            "Hi! I'm your Asset Hub assistant. I can help with asset questions, assignment history, "
            "warranties, repairs, and dashboards."
        ),
    ),
    (
        "small_talk",
        re.compile(
            r"^(?:(?:hi|hello|hey|good morning|good afternoon|good evening)(?: there)?[, ]+)?"
            r"(?:how are you(?: doing)?|how's it going|how are things|what's up|are you okay)$",
            re.IGNORECASE,
        ),
        "I'm ready to help with your asset data. What would you like to check?",
    ),
    (
        "identity",
        re.compile(r"^(?:who are you|what is your name|what's your name|are you a bot)$", re.IGNORECASE),
        "I'm the Asset Hub data assistant. I help find answers in the asset database.",
    ),
    (
        "thanks",
        re.compile(r"^(?:thanks|thank you|many thanks|thx|cheers)$", re.IGNORECASE),
        "You're welcome! What else can I help you find?",
    ),
    (
        "goodbye",
        re.compile(r"^(?:bye|goodbye|see you|that's all|that is all)$", re.IGNORECASE),
        "Goodbye! Come back whenever you need help with asset data.",
    ),
    (
        "help",
        re.compile(
            r"^(?:help|help me|i need help|can you help me|what can you do|what do you do|"
            r"what can you help me with|what can i ask|what questions can i ask|show supported questions)$",
            re.IGNORECASE,
        ),
        (
            "I can answer supported questions about assets, assignments, asset history, purchases, repairs, "
            "warranties, and dashboards. The supported-question selector shows what this database can answer."
        ),
    ),
)


def classify_social(text: str) -> tuple[str, str] | None:
    """Return a safe, short social reply without classifying it as a database question."""
    clean = _NORMALISE.sub(" ", text.strip())
    clean = _TRAILING_PUNCTUATION.sub("", clean).strip()
    for intent, pattern, answer in _PATTERNS:
        if pattern.fullmatch(clean):
            return intent, answer
    return None