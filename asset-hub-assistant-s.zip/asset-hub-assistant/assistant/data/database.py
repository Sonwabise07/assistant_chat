import re
from collections.abc import Iterator
from contextlib import contextmanager

_PARAMETER = re.compile(r"%\((\w+)\)s")


class CursorAdapter:
    """Small adapter exposing dictionary rows and named parameters over pyodbc."""

    def __init__(self, cursor):
        self._cursor = cursor

    def execute(self, query: str, params=None):
        if isinstance(params, dict):
            ordered = []

            def bind(match):
                name = match.group(1)
                if name not in params:
                    raise KeyError(f"Missing SQL parameter: {name}")
                ordered.append(params[name])
                return "?"

            query = _PARAMETER.sub(bind, query)
            self._cursor.execute(query, ordered)
        elif params is None:
            self._cursor.execute(query)
        elif isinstance(params, (tuple, list)):
            self._cursor.execute(query, params)
        else:
            self._cursor.execute(query, (params,))
        return self

    def fetchone(self):
        row = self._cursor.fetchone()
        return self._as_dict(row) if row is not None else None

    def fetchall(self):
        return [self._as_dict(row) for row in self._cursor.fetchall()]

    def _as_dict(self, row):
        if isinstance(row, dict):
            return row
        return {column[0].lower(): value for column, value in zip(self._cursor.description, row)}


class Database:
    def __init__(self, connection_string: str):
        self.connection_string = connection_string

    @contextmanager
    def cursor(self) -> Iterator[CursorAdapter]:
        if not self.connection_string:
            raise RuntimeError("Set SQLSERVER_CONNECTION_STRING before starting the assistant.")
        try:
            import pyodbc
        except ImportError as error:
            raise RuntimeError("Install the project dependencies to enable the SQL Server driver.") from error

        connection = pyodbc.connect(self.connection_string, autocommit=True)
        cursor = connection.cursor()
        try:
            yield CursorAdapter(cursor)
        finally:
            cursor.close()
            connection.close()
