from dataclasses import dataclass

from ..catalog import Catalog


@dataclass(frozen=True)
class Person:
    id: str
    first_name: str
    last_name: str

    @property
    def full_name(self) -> str:
        return f"{self.first_name} {self.last_name}".strip()


@dataclass(frozen=True)
class Lookups:
    """Lookup values currently present in the SQL Server test database."""

    locations: list[str]
    departments: list[str]
    asset_types: list[str]
    statuses: list[str]
    makes: list[str]
    people: list[Person]

    def person_name(self, person_id: str | None) -> str | None:
        return next((person.full_name for person in self.people if person.id == person_id), None)


def _values(cursor, query: str) -> list[str]:
    cursor.execute(query)
    return [row["name"] for row in cursor.fetchall() if row.get("name")]


def load_lookups(cursor) -> Lookups:
    locations = _values(cursor, "SELECT DISTINCT Name AS name FROM dbo.Locations ORDER BY Name")
    departments = _values(cursor, "SELECT DISTINCT Name AS name FROM dbo.Departments ORDER BY Name")
    asset_types = _values(cursor, "SELECT DISTINCT AssetType AS name FROM dbo.Assets ORDER BY AssetType")
    database_statuses = _values(
        cursor,
        "SELECT DISTINCT value AS name FROM (SELECT LifecycleState AS value FROM dbo.Assets "
        "UNION SELECT OperationalStatus FROM dbo.Assets) s WHERE value IS NOT NULL",
    )
    statuses = sorted(set(database_statuses) | {"Available", "Assigned", "In Maintenance", "Retired", "Lost"})
    makes = _values(
        cursor, "SELECT DISTINCT Make AS name FROM dbo.Assets WHERE Make IS NOT NULL ORDER BY Make"
    )
    cursor.execute("SELECT EmployeeId AS id, FullName AS full_name FROM dbo.Employees ORDER BY FullName")
    people = []
    for row in cursor.fetchall():
        pieces = (row["full_name"] or "").strip().split(maxsplit=1)
        people.append(Person(row["id"], pieces[0] if pieces else "", pieces[1] if len(pieces) > 1 else ""))
    return Lookups(locations, departments, asset_types, statuses, makes, people)


def existing_tables(cursor, tables: set[str]) -> set[str]:
    cursor.execute(
        "SELECT LOWER(TABLE_NAME) AS name FROM INFORMATION_SCHEMA.TABLES "
        "WHERE TABLE_SCHEMA = 'dbo' AND TABLE_TYPE IN ('BASE TABLE', 'VIEW')"
    )
    existing = {row["name"] for row in cursor.fetchall()}
    return existing.intersection(name.casefold() for name in tables)


def table_inventory(cursor, catalog: Catalog) -> set[str]:
    cursor.execute(
        "SELECT LOWER(TABLE_NAME) AS name FROM INFORMATION_SCHEMA.TABLES "
        "WHERE TABLE_SCHEMA = 'dbo' AND TABLE_TYPE IN ('BASE TABLE', 'VIEW')"
    )
    return {row["name"] for row in cursor.fetchall()} & {name.casefold() for name in catalog.all_tables}


def available_intents(existing: set[str], catalog: Catalog) -> set[str]:
    return {
        name
        for name, intent in catalog.intents.items()
        if {table.casefold() for table in intent.requires} <= existing
    }
