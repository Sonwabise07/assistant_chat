from .catalog import load_catalog, validate_catalog
from .dashboards.service import DashboardService
from .data.database import Database
from .identity import DemoIdentity
from .queries.runner import QueryRunner
from .service import AssistantService
from .settings import Settings
from .understanding.charts import ChartResolver
from .understanding.classifier import IntentClassifier
from .understanding.ollama import OllamaClassifier
from .understanding.rules import RuleClassifier
from .understanding.slots import SlotExtractor
from .vocabulary import load_vocabulary


def build_service(settings: Settings) -> AssistantService:
    catalog = load_catalog()
    validate_catalog(catalog)
    vocab = load_vocabulary()
    dashboards = DashboardService({}, Database(settings.connection_string))
    titles = {}
    extractor = SlotExtractor(vocab, titles)
    charts = ChartResolver(())
    ollama = OllamaClassifier(settings, catalog, extractor, list(titles), charts.ids)
    classifier = IntentClassifier(settings, vocab, RuleClassifier(catalog, vocab, extractor), ollama)
    return AssistantService(
        catalog,
        vocab,
        Database(settings.connection_string),
        DemoIdentity(settings.demo_email),
        classifier,
        QueryRunner(catalog),
        dashboards,
        charts,
    )


