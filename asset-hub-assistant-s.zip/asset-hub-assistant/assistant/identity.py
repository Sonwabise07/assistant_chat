from dataclasses import dataclass


@dataclass(frozen=True)
class CurrentUser:
    id: str
    name: str
    department_id: str | None = None


class DemoIdentity:
    """Standalone test identity; this does not enforce row-level authorization."""

    def __init__(self, email: str = ""):
        self.email = email.strip().lower()

    def resolve(self, cursor, email: str | None = None) -> CurrentUser:
        selected_email = (email or self.email).strip().lower()
        if not selected_email:
            return CurrentUser(id="", name="Test user")
        cursor.execute(
            "SELECT EmployeeId AS id, FullName AS name, DepartmentId AS department_id "
            "FROM dbo.Employees WHERE LOWER(Email) = ?",
            (selected_email,),
        )
        row = cursor.fetchone()
        return CurrentUser(row["id"], row["name"], row["department_id"]) if row else CurrentUser("", "Guest")
