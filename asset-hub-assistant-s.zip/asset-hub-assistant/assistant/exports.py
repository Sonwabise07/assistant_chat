"""Create Word and Excel files from a whitelisted assistant query result."""

import re
from datetime import datetime, timezone
from io import BytesIO

from docx import Document
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill
from openpyxl.utils import get_column_letter

ROW_CAP = 5000


def build_report(reply: dict, question: str, file_format: str) -> tuple[bytes, str, str]:
    """Return (file bytes, media type, extension) for an assistant reply."""
    table = reply.get("table")
    if not table or not table.get("columns"):
        raise ValueError("There are no tabular results to export.")
    if file_format == "xlsx":
        return (
            _excel(reply, question),
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            "xlsx",
        )
    if file_format == "docx":
        return (
            _word(reply, question),
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            "docx",
        )
    raise ValueError("Choose Excel (.xlsx) or Word (.docx).")


def _plain(text: str) -> str:
    return re.sub(r"\*\*(.+?)\*\*", r"\1", str(text))


def _excel(reply: dict, question: str) -> bytes:
    table = reply["table"]
    workbook = Workbook()
    sheet = workbook.active
    sheet.title = "Assistant report"
    sheet.append(["Asset Hub Assistant Report"])
    sheet["A1"].font = Font(size=16, bold=True, color="FFFFFF")
    sheet["A1"].fill = PatternFill("solid", fgColor="131038")
    sheet.append(["Question", _excel_text(question)])
    sheet.append(["Answer", _excel_text(_plain(reply.get("answer", "")))])
    sheet.append(["Source", _excel_text(reply.get("source") or "")])
    sheet.append(["Rows included", min(len(table["rows"]), ROW_CAP)])
    sheet.append(["Note", f"Export is capped at {ROW_CAP:,} rows per report."])
    sheet.append([])
    header_row = sheet.max_row + 1
    sheet.append(table["columns"])
    for cell in sheet[header_row]:
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor="1E9AE0")
    for row in table["rows"][:ROW_CAP]:
        sheet.append([_excel_text(row.get(key, "")) for key in table["columns"]])
    sheet.freeze_panes = f"A{header_row + 1}"
    for column in sheet.columns:
        width = min(max(max((len(str(cell.value or "")) for cell in column), default=0) + 2, 12), 42)
        sheet.column_dimensions[get_column_letter(column[0].column)].width = width
    output = BytesIO()
    workbook.save(output)
    return output.getvalue()


def _word(reply: dict, question: str) -> bytes:
    table_data = reply["table"]
    document = Document()
    document.add_heading("Asset Hub Assistant Report", 0)
    document.add_paragraph(f"Question: {question}")
    document.add_paragraph(f"Answer: {_plain(reply.get('answer', ''))}")
    if reply.get("source"):
        document.add_paragraph(f"Source: {reply['source']}")
    document.add_paragraph(
        f"Rows included: {min(len(table_data['rows']), ROW_CAP):,}. "
        f"Exports are capped at {ROW_CAP:,} rows per report."
    )
    table = document.add_table(rows=1, cols=len(table_data["columns"]))
    table.style = "Light Shading Accent 1"
    for cell, heading in zip(table.rows[0].cells, table_data["columns"], strict=True):
        cell.text = str(heading).replace("_", " ").title()
    for row in table_data["rows"][:ROW_CAP]:
        cells = table.add_row().cells
        for cell, key in zip(cells, table_data["columns"], strict=True):
            cell.text = str(row.get(key, ""))
    output = BytesIO()
    document.save(output)
    return output.getvalue()


def _excel_text(value) -> str:
    text = str(value if value is not None else "")
    if text[:1] in ("=", "+", "-", "@"):
        text = "'" + text
    return text


def filename(file_format: str) -> str:
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
    return f"asset-hub-report-{stamp}.{file_format}"