SELECT a.AssetNo AS asset_no, CONCAT_WS(' ', a.Make, a.Model) AS description,
       CONVERT(varchar(11), aa.AssignedAt, 106) AS assigned,
       CONVERT(varchar(11), aa.ReturnedAt, 106) AS returned,
       COALESCE(aa.AssignedBy, '-') AS assigned_by,
       CASE WHEN aa.ReturnedAt IS NULL THEN 'Still assigned' ELSE 'Not recorded' END AS return_condition,
       COUNT_BIG(*) OVER () AS total
FROM dbo.AssetAssignments aa
JOIN scoped a ON a.AssetId = aa.AssetId
WHERE aa.EmployeeId = %(person_id)s
  AND (
       (%(assignment_mode)s IN ('assigned', 'all_events') AND aa.AssignedAt >= CAST(%(date_from)s AS date) AND aa.AssignedAt < DATEADD(day, 1, CAST(%(date_to)s AS date)))
    OR (%(assignment_mode)s IN ('returned', 'all_events') AND aa.ReturnedAt >= CAST(%(date_from)s AS date) AND aa.ReturnedAt < DATEADD(day, 1, CAST(%(date_to)s AS date)))
    OR (%(assignment_mode)s = 'held' AND aa.AssignedAt < DATEADD(day, 1, CAST(%(date_to)s AS date)) AND (aa.ReturnedAt IS NULL OR aa.ReturnedAt >= CAST(%(date_from)s AS date)))
  )
ORDER BY aa.AssignedAt DESC, a.AssetNo
OFFSET 0 ROWS FETCH NEXT %(row_limit)s ROWS ONLY
