
(CAST(%(asset_type)s AS nvarchar(100)) IS NULL OR a.AssetType = %(asset_type)s)
AND (CAST(%(status)s AS nvarchar(100)) IS NULL OR
     (LOWER(CAST(%(status)s AS nvarchar(100))) = 'available' AND a.EmployeeId IS NULL AND a.StoreroomId IS NOT NULL) OR
     (LOWER(CAST(%(status)s AS nvarchar(100))) = 'assigned' AND a.EmployeeId IS NOT NULL) OR
     (LOWER(CAST(%(status)s AS nvarchar(100))) = 'in maintenance' AND (a.LifecycleState = 'InRepair' OR a.OperationalStatus IN ('Faulty', 'Damaged'))) OR
     (LOWER(CAST(%(status)s AS nvarchar(100))) NOT IN ('available', 'assigned', 'in maintenance') AND
      (a.LifecycleState = %(status)s OR a.OperationalStatus = %(status)s)))
AND (CAST(%(location)s AS nvarchar(200)) IS NULL OR l.Name = %(location)s)
AND (CAST(%(department)s AS nvarchar(200)) IS NULL OR d.Name = %(department)s)
AND (CAST(%(make)s AS nvarchar(100)) IS NULL OR a.Make LIKE CONCAT(%(make)s, N'%'))
AND (CAST(%(older_than)s AS int) IS NULL OR a.AcquisitionDate <= DATEADD(month, -%(older_than)s, CONVERT(date, GETDATE())))
