SELECT a.AssetNo AS asset_no, CONCAT_WS(' ', a.Make, a.Model) AS description,
       e.FullName AS holder, COALESCE(a.LifecycleState, a.OperationalStatus) AS status,
       COALESCE(l.Name, '-') AS location, COUNT_BIG(*) OVER () AS total,
       SUM(CASE WHEN a.AssetType = 'Laptop' THEN 1 ELSE 0 END) OVER () AS laptops
FROM scoped a
JOIN dbo.Employees e ON e.EmployeeId = a.EmployeeId
LEFT JOIN dbo.Locations l ON l.LocationId = a.LocationId
LEFT JOIN dbo.Departments d ON d.DepartmentId = a.DepartmentId
WHERE e.IsActive = 0 AND {{FILTERS}}
ORDER BY a.AssetNo OFFSET 0 ROWS FETCH NEXT %(row_limit)s ROWS ONLY
