, matched_asset AS (
    SELECT TOP (1) a.AssetId, a.AssetNo
    FROM scoped a
    WHERE UPPER(REPLACE(REPLACE(REPLACE(a.AssetNo, '-', ''), ' ', ''), '_', '')) = %(asset_ref)s
       OR UPPER(REPLACE(REPLACE(REPLACE(COALESCE(a.SerialNumber, ''), '-', ''), ' ', ''), '_', '')) = %(asset_ref)s
       OR UPPER(REPLACE(REPLACE(REPLACE(COALESCE(a.AssetTag, ''), '-', ''), ' ', ''), '_', '')) = %(asset_ref)s
)
SELECT m.AssetNo AS asset_no, h.Action AS event,
       CONVERT(varchar(10), h.ChangedAt, 23) AS occurred,
       COUNT_BIG(h.HistoryId) OVER () AS total
FROM matched_asset m
LEFT JOIN dbo.AssetHistory h ON h.AssetId = m.AssetId
ORDER BY h.ChangedAt DESC, h.HistoryId DESC
OFFSET 0 ROWS FETCH NEXT %(row_limit)s ROWS ONLY
