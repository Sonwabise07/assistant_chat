
LEFT JOIN dbo.Locations l ON l.LocationId = a.LocationId
LEFT JOIN dbo.Departments d ON d.DepartmentId = a.DepartmentId
LEFT JOIN dbo.Employees e ON e.EmployeeId = a.EmployeeId
