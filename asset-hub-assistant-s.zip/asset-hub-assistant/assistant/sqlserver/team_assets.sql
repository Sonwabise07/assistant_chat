SELECT a.AssetNo AS asset_no, CONCAT_WS(' ', a.Make, a.Model) AS description,
       CASE WHEN a.EmployeeId IS NULL AND a.StoreroomId IS NOT NULL THEN 'Available' ELSE COALESCE(a.LifecycleState, a.OperationalStatus) END AS status,
       COALESCE(l.Name, '-') AS location, COALESCE(e.FullName, a.EmployeeName, '-') AS assigned_to,
       d.Name AS department, COUNT_BIG(*) OVER () AS total
FROM scoped a {{JOINS}}
WHERE a.DepartmentId = %(user_department)s AND {{FILTERS}}
ORDER BY a.AssetNo OFFSET 0 ROWS FETCH NEXT %(row_limit)s ROWS ONLY
