/* Synthetic, non-production test schema aligned to the supplied CtrlFind EF model. */
IF DB_ID(N'AssetHubAssistantTest') IS NULL CREATE DATABASE AssetHubAssistantTest;
GO
USE AssetHubAssistantTest;
GO
IF OBJECT_ID(N'dbo.Assets', N'U') IS NOT NULL DROP TABLE dbo.Assets;
IF OBJECT_ID(N'dbo.AssetTransfers', N'U') IS NOT NULL DROP TABLE dbo.AssetTransfers;
IF OBJECT_ID(N'dbo.AssetHistory', N'U') IS NOT NULL DROP TABLE dbo.AssetHistory;
IF OBJECT_ID(N'dbo.AssetAssignments', N'U') IS NOT NULL DROP TABLE dbo.AssetAssignments;
IF OBJECT_ID(N'dbo.Storerooms', N'U') IS NOT NULL DROP TABLE dbo.Storerooms;
IF OBJECT_ID(N'dbo.Locations', N'U') IS NOT NULL DROP TABLE dbo.Locations;
IF OBJECT_ID(N'dbo.Departments', N'U') IS NOT NULL DROP TABLE dbo.Departments;
IF OBJECT_ID(N'dbo.Employees', N'U') IS NOT NULL DROP TABLE dbo.Employees;
GO
CREATE TABLE dbo.Departments (DepartmentId nvarchar(64) NOT NULL PRIMARY KEY, Name nvarchar(200) NOT NULL);
CREATE TABLE dbo.Locations (LocationId nvarchar(64) NOT NULL PRIMARY KEY, Name nvarchar(200) NOT NULL, Region nvarchar(100) NULL, Building nvarchar(150) NULL, Floor nvarchar(50) NULL);
CREATE TABLE dbo.Employees (EmployeeId nvarchar(64) NOT NULL PRIMARY KEY, FullName nvarchar(200) NOT NULL, Email nvarchar(320) NULL, DepartmentId nvarchar(64) NULL, IsActive bit NOT NULL DEFAULT 1);
CREATE TABLE dbo.Storerooms (StoreroomId nvarchar(64) NOT NULL PRIMARY KEY, Name nvarchar(200) NOT NULL, LocationId nvarchar(64) NULL);
CREATE TABLE dbo.Assets (
 AssetId nvarchar(64) NOT NULL PRIMARY KEY, AssetNo nvarchar(50) NOT NULL UNIQUE, AssetTag nvarchar(100) NULL,
 SerialNumber nvarchar(150) NULL, AssetType nvarchar(100) NOT NULL, Make nvarchar(100) NULL, Model nvarchar(150) NULL,
 LifecycleState nvarchar(50) NOT NULL, OperationalStatus nvarchar(50) NOT NULL, EmployeeId nvarchar(64) NULL,
 EmployeeName nvarchar(200) NULL, LocationId nvarchar(64) NULL, Region nvarchar(100) NULL, Building nvarchar(150) NULL,
 Floor nvarchar(50) NULL, DepartmentId nvarchar(64) NULL, StoreroomId nvarchar(64) NULL, WarrantyEnd datetime2 NULL,
 PurchaseCost decimal(18,2) NULL, LastAuditDate datetime2 NULL, CreatedAtUtc datetime2 NOT NULL DEFAULT SYSUTCDATETIME(),
 UpdatedAtUtc datetime2 NOT NULL DEFAULT SYSUTCDATETIME(), RowVersion rowversion NOT NULL, Category nvarchar(100) NULL,
 CompanyEntity nvarchar(150) NULL, CostCentre nvarchar(50) NULL, PurchaseOrder nvarchar(100) NULL, InvoiceReference nvarchar(100) NULL,
 AcquisitionDate datetime2 NULL, WarrantyStart datetime2 NULL, AuditOutcome nvarchar(50) NULL, EncryptionStatus nvarchar(50) NULL,
 CustodyAgreementSigned bit NOT NULL DEFAULT 0, HealthIndicator nvarchar(50) NULL, Notes nvarchar(2000) NULL
);
CREATE TABLE dbo.AssetAssignments (AssignmentId bigint IDENTITY PRIMARY KEY, AssetId nvarchar(64) NOT NULL, EmployeeId nvarchar(64) NOT NULL, EmployeeName nvarchar(200) NULL, AssignedAt datetime2 NOT NULL, ReturnedAt datetime2 NULL, CustodyAgreementReference nvarchar(200) NULL, AssignedBy nvarchar(200) NULL, LocationId nvarchar(64) NULL, Notes nvarchar(2000) NULL);
CREATE TABLE dbo.AssetHistory (HistoryId bigint IDENTITY PRIMARY KEY, AssetId nvarchar(64) NOT NULL, Action nvarchar(100) NOT NULL, Summary nvarchar(2000) NULL, DetailsJson nvarchar(max) NULL, ChangedBy nvarchar(200) NULL, ChangedAt datetime2 NOT NULL);
CREATE TABLE dbo.AssetTransfers (TransferId bigint IDENTITY PRIMARY KEY, AssetId nvarchar(64) NOT NULL, TransferType nvarchar(50) NOT NULL, TargetId nvarchar(64) NOT NULL, Status nvarchar(50) NOT NULL, RequestedBy nvarchar(200) NULL, Notes nvarchar(2000) NULL, RequestedAt datetime2 NOT NULL, CompletedAt datetime2 NULL);
GO
INSERT dbo.Departments (DepartmentId, Name) VALUES ('IT', 'IT'), ('FIN', 'Finance');
INSERT dbo.Locations (LocationId, Name, Region, Building) VALUES ('LOC-JHB', 'Johannesburg HQ', 'Gauteng', 'Main'), ('LOC-CPT', 'Cape Town Office', 'Western Cape', 'Harbour');
INSERT dbo.Employees (EmployeeId, FullName, Email, DepartmentId, IsActive) VALUES ('EMP-001', 'Test Employee', 'test.employee@example.invalid', 'IT', 1), ('EMP-002', 'Former Employee', 'former.employee@example.invalid', 'FIN', 0);
INSERT dbo.Storerooms (StoreroomId, Name, LocationId) VALUES ('STORE-JHB', 'Johannesburg IT Store', 'LOC-JHB');
INSERT dbo.Assets (AssetId, AssetNo, AssetTag, SerialNumber, AssetType, Make, Model, LifecycleState, OperationalStatus, EmployeeId, EmployeeName, LocationId, DepartmentId, StoreroomId, PurchaseCost, AcquisitionDate, WarrantyEnd, CustodyAgreementSigned)
VALUES
('AST-001', 'AST-000001', 'TAG-001', 'SN-001', 'Laptop', 'Dell', 'Latitude 5440', 'InStock', 'Available', NULL, NULL, 'LOC-JHB', 'IT', 'STORE-JHB', 18000.00, '2025-03-15', '2028-03-15', 0),
('AST-002', 'AST-000002', 'TAG-002', 'SN-002', 'Laptop', 'Dell', 'Latitude 5430', 'Assigned', 'InUse', 'EMP-001', 'Test Employee', 'LOC-JHB', 'IT', NULL, 16000.00, '2024-02-01', '2027-02-01', 1),
('AST-003', 'AST-000003', 'TAG-003', 'SN-003', 'Monitor', 'LG', '27UK850', 'InStock', 'Available', NULL, NULL, 'LOC-CPT', 'FIN', 'STORE-JHB', 6000.00, '2023-06-10', '2025-06-10', 0),
('AST-004', 'AST-000004', 'TAG-004', 'SN-004', 'Printer', 'HP', 'LaserJet', 'InStock', 'Available', NULL, NULL, 'LOC-JHB', 'IT', NULL, 9000.00, '2022-01-12', NULL, 0),
('AST-005', 'AST-000005', 'TAG-005', 'SN-005', 'Desktop', 'HP', 'ProDesk', 'Assigned', 'InUse', 'EMP-002', 'Former Employee', 'LOC-CPT', 'FIN', NULL, 12000.00, '2023-08-20', '2026-08-20', 1);
INSERT dbo.AssetAssignments (AssetId, EmployeeId, EmployeeName, AssignedAt, ReturnedAt, AssignedBy) VALUES ('AST-002', 'EMP-001', 'Test Employee', '2024-02-01', NULL, 'Test Admin');
INSERT dbo.AssetHistory (AssetId, Action, Summary, ChangedBy, ChangedAt) VALUES ('AST-002', 'Assigned', 'Assigned to Test Employee', 'Test Admin', '2024-02-01');
GO
