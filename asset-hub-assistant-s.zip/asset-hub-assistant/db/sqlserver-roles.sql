/* Run as a database owner in AssetHubAssistantTest; grant only read access. */
USE AssetHubAssistantTest;
GO
IF DATABASE_PRINCIPAL_ID(N'assistant_readonly') IS NULL CREATE ROLE assistant_readonly;
GRANT SELECT ON dbo.Assets TO assistant_readonly;
GRANT SELECT ON dbo.Employees TO assistant_readonly;
GRANT SELECT ON dbo.Departments TO assistant_readonly;
GRANT SELECT ON dbo.Locations TO assistant_readonly;
GRANT SELECT ON dbo.Storerooms TO assistant_readonly;
GRANT SELECT ON dbo.AssetAssignments TO assistant_readonly;
GRANT SELECT ON dbo.AssetHistory TO assistant_readonly;
GRANT SELECT ON dbo.AssetTransfers TO assistant_readonly;
GO
