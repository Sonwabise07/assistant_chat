import type { AskRequest, Context, Dashboard, DashboardSummary, Meta, Reply } from './types';

const BASE = '/api';

export class ApiError extends Error {
  constructor(
    readonly status: number,
    message: string,
  ) {
    super(message);
  }
}

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const response = await fetch(BASE + path, init);
  if (!response.ok) {
    const body = await response.json().catch(() => ({ error: response.statusText }));
    throw new ApiError(response.status, body.error ?? response.statusText);
  }
  return response.json() as Promise<T>;
}

export const api = {
  meta: () => request<Meta>('/assistant/meta'),
  ask: (body: AskRequest) =>
    request<Reply>('/assistant/ask', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    }),
  dashboards: () => request<DashboardSummary[]>('/dashboards'),
  dashboard: (id: string) => request<Dashboard>(`/dashboards/${id}`),
  exportReport: async (question: string, context: Context | null, format: 'xlsx' | 'docx') => {
    const response = await fetch(`${BASE}/assistant/export`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ question, context, format }),
    });
    if (!response.ok) {
      const body = await response.json().catch(() => ({ error: response.statusText }));
      throw new ApiError(response.status, body.error ?? response.statusText);
    }
    const blob = await response.blob();
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = `asset-hub-report.${format}`;
    anchor.click();
    URL.revokeObjectURL(url);
  },
};
