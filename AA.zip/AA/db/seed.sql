-- Dummy data for testing only. Load into an empty database.
-- Dates are relative to today, so 'this month' and 'next month' questions always return data.
BEGIN;
INSERT INTO asset_management.departments (name, description) VALUES
  ('IT', 'IT department'),
  ('Finance', 'Finance department'),
  ('Sales', 'Sales department'),
  ('HR', 'HR department'),
  ('Operations', 'Operations department');
INSERT INTO asset_management.locations (name, building, floor, room, description) VALUES
  ('Sandton HQ', 'Head Office', '3', NULL, NULL),
  ('Umhlanga', 'Umhlanga Ridge', '2', NULL, NULL),
  ('Midrand DC', 'Distribution Centre', 'G', 'Storeroom A', NULL),
  ('East London', 'Quigney Office', '1', NULL, NULL);
INSERT INTO asset_management.users (employee_number, first_name, last_name, email, department_id, is_active) VALUES
  ('EMP001', 'Thandi', 'Nkosi', 'thandi.nkosi@example.co.za', 1, true),
  ('EMP002', 'Sipho', 'Dlamini', 'sipho.dlamini@example.co.za', 2, true),
  ('EMP003', 'Naledi', 'Mokoena', 'naledi.mokoena@example.co.za', 2, true),
  ('EMP004', 'Pieter', 'van Wyk', 'pieter.vanwyk@example.co.za', 3, true),
  ('EMP005', 'Ayesha', 'Naidoo', 'ayesha.naidoo@example.co.za', 3, true),
  ('EMP006', 'Thabo', 'Baloyi', 'thabo.baloyi@example.co.za', 5, true),
  ('EMP007', 'Zanele', 'Khumalo', 'zanele.khumalo@example.co.za', 4, true),
  ('EMP008', 'Michael', 'Govender', 'michael.govender@example.co.za', 1, true),
  ('EMP009', 'Refilwe', 'Molefe', 'refilwe.molefe@example.co.za', 5, true),
  ('EMP010', 'Johan', 'Botha', 'johan.botha@example.co.za', 3, true);
UPDATE asset_management.users SET is_active = false WHERE employee_number IN ('EMP009', 'EMP010');
INSERT INTO asset_management.suppliers (name, contact_person, email) VALUES
  ('Dell South Africa', 'Account Desk', 'dell@example.co.za'),
  ('iStore Business', 'Corporate Sales', 'istore@example.co.za'),
  ('TechFix Repairs', 'Workshop Lead', 'techfix@example.co.za');
INSERT INTO asset_management.assets (asset_no, description, tracking_no, asset_type_id, status_id, location_id, department_id, assigned_to_user_id, serial_number, purchase_date, purchase_price, warranty_expiry_date) VALUES
  ('AST-0001', 'Dell Latitude 5440 laptop', 'EXT-100000', 1, 2, 2, 1, 1, 'NB4DU7GCPH', CURRENT_DATE - 214, 27200, (date_trunc('month', CURRENT_DATE) + interval '1 month' + interval '6 days')::date),
  ('AST-0002', 'Dell Latitude 7440 laptop', 'EXT-100001', 1, 2, 3, 2, 2, 'BU8WUBUBHT', (date_trunc('month', CURRENT_DATE) + interval '1 days')::date, 30800, ((date_trunc('month', CURRENT_DATE) + interval '1 days')::date + interval '3 years')::date),
  ('AST-0003', 'Dell Latitude 5440 laptop', 'EXT-100002', 1, 2, 4, 2, 3, 'PTUTXDUGDY', (date_trunc('month', CURRENT_DATE) + interval '2 days')::date, 24150, ((date_trunc('month', CURRENT_DATE) + interval '2 days')::date + interval '3 years')::date),
  ('AST-0004', 'Dell Latitude 7440 laptop', 'EXT-100003', 1, 2, 1, 3, 4, 'GXPLUQK3YH', CURRENT_DATE - 693, 31050, (date_trunc('month', CURRENT_DATE) + interval '1 month' + interval '18 days')::date),
  ('AST-0005', 'Dell Latitude 5440 laptop', 'EXT-100004', 1, 2, 2, 3, 5, 'S6ZK9DP2ER', (date_trunc('month', CURRENT_DATE - interval '1 month') + interval '9 days')::date, 31200, ((date_trunc('month', CURRENT_DATE - interval '1 month') + interval '9 days')::date + interval '3 years')::date),
  ('AST-0006', 'Dell Latitude 7440 laptop', 'EXT-100005', 1, 2, 3, 5, 6, 'X2U6LYVUQ4', (date_trunc('month', CURRENT_DATE - interval '1 month') + interval '10 days')::date, 22650, ((date_trunc('month', CURRENT_DATE - interval '1 month') + interval '10 days')::date + interval '3 years')::date),
  ('AST-0007', 'Dell Latitude 5440 laptop', 'EXT-100006', 1, 2, 4, 4, 7, 'RXBYW94KNX', (date_trunc('month', CURRENT_DATE - interval '1 month') + interval '11 days')::date, 37100, ((date_trunc('month', CURRENT_DATE - interval '1 month') + interval '11 days')::date + interval '3 years')::date),
  ('AST-0008', 'Dell Latitude 7440 laptop', 'EXT-100007', 1, 2, 1, 1, 8, 'MVRGKZN7RF', CURRENT_DATE - 532, 22350, (date_trunc('month', CURRENT_DATE) + interval '1 month' + interval '24 days')::date),
  ('AST-0009', 'Dell Latitude 5440 laptop', 'EXT-100008', 1, 2, 2, 5, 9, '645JPM68EF', CURRENT_DATE - 344, 28450, (CURRENT_DATE - 344 + interval '3 years')::date),
  ('AST-0010', 'Dell Latitude 7440 laptop', 'EXT-100009', 1, 1, 3, NULL, NULL, 'A4FKETVLE5', CURRENT_DATE - 298, 25700, (date_trunc('month', CURRENT_DATE) + interval '20 days')::date),
  ('AST-0011', 'Dell Latitude 5440 laptop', 'EXT-100010', 1, 1, 1, NULL, NULL, 'XB6253NNDW', CURRENT_DATE - 730, 37200, (CURRENT_DATE - 730 + interval '3 years')::date),
  ('AST-0012', 'Dell Latitude 7440 laptop', 'EXT-100011', 1, 1, 3, NULL, NULL, '9QDVDUT8VC', CURRENT_DATE - 128, 23000, (CURRENT_DATE - 128 + interval '3 years')::date),
  ('AST-0013', 'MacBook Pro 14 laptop', 'EXT-100012', 1, 3, 1, NULL, NULL, 'EJMMD59QRC', CURRENT_DATE - 445, 35350, CURRENT_DATE + 45),
  ('AST-0014', 'MacBook Air 13 laptop', 'EXT-100013', 1, 3, 2, NULL, NULL, 'ZRYSG8MY72', CURRENT_DATE - 410, 33650, (CURRENT_DATE - 410 + interval '3 years')::date),
  ('AST-0015', 'MacBook Pro 14 laptop', 'EXT-100014', 1, 4, 3, NULL, NULL, '5YJMF2T2LH', CURRENT_DATE - 718, 36750, (CURRENT_DATE - 718 + interval '3 years')::date),
  ('AST-0016', 'MacBook Air 13 laptop', 'EXT-100015', 1, 2, 3, 3, 10, '534ZHSMAAJ', CURRENT_DATE - 836, 45000, (CURRENT_DATE - 836 + interval '3 years')::date),
  ('AST-0017', 'Dell P2423 24in monitor', 'EXT-100016', 3, 2, 4, 1, 1, 'VM3ZM9CDRL', CURRENT_DATE - 769, 4150, (CURRENT_DATE - 769 + interval '3 years')::date),
  ('AST-0018', 'Dell U2723QE 27in monitor', 'EXT-100017', 3, 2, 1, 2, 2, '9VA7MW4DNY', (date_trunc('month', CURRENT_DATE) + interval '2 days')::date, 5150, ((date_trunc('month', CURRENT_DATE) + interval '2 days')::date + interval '3 years')::date),
  ('AST-0019', 'Dell P2423 24in monitor', 'EXT-100018', 3, 2, 2, 2, 3, '6PWC8ZQZCF', (date_trunc('month', CURRENT_DATE - interval '1 month') + interval '23 days')::date, 3900, ((date_trunc('month', CURRENT_DATE - interval '1 month') + interval '23 days')::date + interval '3 years')::date),
  ('AST-0020', 'Dell U2723QE 27in monitor', 'EXT-100019', 3, 2, 3, 3, 4, 'E63E49XMTE', CURRENT_DATE - 88, 7450, (CURRENT_DATE - 88 + interval '3 years')::date),
  ('AST-0021', 'Dell P2423 24in monitor', 'EXT-100020', 3, 2, 4, 3, 5, '9WS7P54GJK', (date_trunc('month', CURRENT_DATE) + interval '2 days')::date, 3050, CURRENT_DATE + 75),
  ('AST-0022', 'Dell U2723QE 27in monitor', 'EXT-100021', 3, 2, 1, 5, 6, 'UJPE7MQU6P', (date_trunc('month', CURRENT_DATE - interval '1 month') + interval '6 days')::date, 4100, ((date_trunc('month', CURRENT_DATE - interval '1 month') + interval '6 days')::date + interval '3 years')::date),
  ('AST-0023', 'Dell P2423 24in monitor', 'EXT-100022', 3, 2, 2, 4, 7, 'STSAQFA3FR', (date_trunc('month', CURRENT_DATE - interval '1 month') + interval '7 days')::date, 7150, ((date_trunc('month', CURRENT_DATE - interval '1 month') + interval '7 days')::date + interval '3 years')::date),
  ('AST-0024', 'Dell U2723QE 27in monitor', 'EXT-100023', 3, 2, 3, 1, 8, 'BXSR26BGBD', CURRENT_DATE - 629, 6250, (CURRENT_DATE - 629 + interval '3 years')::date),
  ('AST-0025', 'Dell P2423 24in monitor', 'EXT-100024', 3, 2, 4, 5, 9, '27QVSSYQTR', CURRENT_DATE - 88, 5050, (CURRENT_DATE - 88 + interval '3 years')::date),
  ('AST-0026', 'Dell U2723QE 27in monitor', 'EXT-100025', 3, 2, 1, 3, 10, 'S6776GQPNL', CURRENT_DATE - 775, 7250, CURRENT_DATE - 30),
  ('AST-0027', 'Dell P2423 24in monitor', 'EXT-100026', 3, 2, 2, 1, 1, 'CX36EYXE68', CURRENT_DATE - 498, 6000, (CURRENT_DATE - 498 + interval '3 years')::date),
  ('AST-0028', 'Dell U2723QE 27in monitor', 'EXT-100027', 3, 1, 3, NULL, NULL, 'NR94FPSLGL', CURRENT_DATE - 156, 4000, (CURRENT_DATE - 156 + interval '3 years')::date),
  ('AST-0029', 'Dell P2423 24in monitor', 'EXT-100028', 3, 1, 1, NULL, NULL, 'LQYNSK8D7H', CURRENT_DATE - 79, 6250, (CURRENT_DATE - 79 + interval '3 years')::date),
  ('AST-0030', 'Dell U2723QE 27in monitor', 'EXT-100029', 3, 1, 3, NULL, NULL, 'JB2JEP74JE', CURRENT_DATE - 146, 6950, (CURRENT_DATE - 146 + interval '3 years')::date),
  ('AST-0031', 'Dell P2423 24in monitor', 'EXT-100030', 3, 3, 3, NULL, NULL, 'RLJ3F6JACJ', CURRENT_DATE - 644, 7150, CURRENT_DATE - 120),
  ('AST-0032', 'Dell U2723QE 27in monitor', 'EXT-100031', 3, 4, 4, NULL, NULL, 'C5QLT7JESH', CURRENT_DATE - 287, 5750, (CURRENT_DATE - 287 + interval '3 years')::date),
  ('AST-0033', 'Dell OptiPlex 7010 desktop', 'EXT-100032', 2, 2, 3, 2, 2, 'JF7WSGQXJ3', CURRENT_DATE - 225, 14200, (CURRENT_DATE - 225 + interval '3 years')::date),
  ('AST-0034', 'Dell OptiPlex 7010 desktop', 'EXT-100033', 2, 1, 3, NULL, NULL, 'BAS9SHQXWX', (date_trunc('month', CURRENT_DATE - interval '1 month') + interval '18 days')::date, 16000, CURRENT_DATE - 400),
  ('AST-0035', 'Samsung Galaxy S24 phone', 'EXT-100034', 4, 2, 4, 2, 3, '9KGHG6ZE99', CURRENT_DATE - 462, 14100, (CURRENT_DATE - 462 + interval '3 years')::date),
  ('AST-0036', 'Samsung Galaxy S24 phone', 'EXT-100035', 4, 2, 1, 3, 4, 'CZJFC45XKH', CURRENT_DATE - 74, 14650, (CURRENT_DATE - 74 + interval '3 years')::date),
  ('AST-0037', 'Samsung Galaxy S24 phone', 'EXT-100036', 4, 5, 1, NULL, NULL, 'FJAML9LB6G', CURRENT_DATE - 530, 13600, (CURRENT_DATE - 530 + interval '3 years')::date),
  ('AST-0038', 'Apple iPad 10th Gen tablet', 'EXT-100037', 5, 5, 2, NULL, NULL, 'NRSGSAJCNB', CURRENT_DATE - 403, 8700, (CURRENT_DATE - 403 + interval '3 years')::date),
  ('AST-0039', 'HP LaserJet Pro MFP printer', 'EXT-100038', 6, 1, 1, NULL, NULL, 'WC85E63V2Z', CURRENT_DATE - 371, 8100, (CURRENT_DATE - 371 + interval '3 years')::date),
  ('AST-0040', 'Canon imageRUNNER printer', 'EXT-100039', 6, 2, 2, 3, 5, 'ZWB46WZ3ES', CURRENT_DATE - 350, 21450, (CURRENT_DATE - 350 + interval '3 years')::date),
  ('AST-0041', 'Cisco Catalyst 2960 switch', 'EXT-100040', 7, 1, 1, NULL, NULL, '34U6XYHAEM', CURRENT_DATE - 892, 21100, (CURRENT_DATE - 892 + interval '3 years')::date),
  ('AST-0042', 'Ubiquiti UniFi access point', 'EXT-100041', 7, 2, 3, 5, 6, 'TWWXRA3ZST', CURRENT_DATE - 522, 3300, (CURRENT_DATE - 522 + interval '3 years')::date);
INSERT INTO asset_management.asset_assignments (asset_id, user_id, assigned_date, returned_date, assigned_by_user_id, comment) VALUES
  (1, 1, LEAST(CURRENT_TIMESTAMP, (SELECT purchase_date FROM asset_management.assets WHERE asset_id=1)::timestamptz + interval '5 days'), NULL, 3, 'Issued'),
  (2, 2, LEAST(CURRENT_TIMESTAMP, (SELECT purchase_date FROM asset_management.assets WHERE asset_id=2)::timestamptz + interval '5 days'), NULL, 3, 'Issued'),
  (3, 3, LEAST(CURRENT_TIMESTAMP, (SELECT purchase_date FROM asset_management.assets WHERE asset_id=3)::timestamptz + interval '5 days'), NULL, 3, 'Issued'),
  (4, 4, LEAST(CURRENT_TIMESTAMP, (SELECT purchase_date FROM asset_management.assets WHERE asset_id=4)::timestamptz + interval '5 days'), NULL, 3, 'Issued'),
  (5, 5, LEAST(CURRENT_TIMESTAMP, (SELECT purchase_date FROM asset_management.assets WHERE asset_id=5)::timestamptz + interval '5 days'), NULL, 3, 'Issued'),
  (6, 6, LEAST(CURRENT_TIMESTAMP, (SELECT purchase_date FROM asset_management.assets WHERE asset_id=6)::timestamptz + interval '5 days'), NULL, 3, 'Issued'),
  (7, 7, LEAST(CURRENT_TIMESTAMP, (SELECT purchase_date FROM asset_management.assets WHERE asset_id=7)::timestamptz + interval '5 days'), NULL, 3, 'Issued'),
  (8, 8, LEAST(CURRENT_TIMESTAMP, (SELECT purchase_date FROM asset_management.assets WHERE asset_id=8)::timestamptz + interval '5 days'), NULL, 3, 'Issued'),
  (9, 9, LEAST(CURRENT_TIMESTAMP, (SELECT purchase_date FROM asset_management.assets WHERE asset_id=9)::timestamptz + interval '5 days'), NULL, 3, 'Issued'),
  (16, 10, LEAST(CURRENT_TIMESTAMP, (SELECT purchase_date FROM asset_management.assets WHERE asset_id=16)::timestamptz + interval '5 days'), NULL, 3, 'Issued'),
  (17, 1, LEAST(CURRENT_TIMESTAMP, (SELECT purchase_date FROM asset_management.assets WHERE asset_id=17)::timestamptz + interval '5 days'), NULL, 3, 'Issued'),
  (18, 2, LEAST(CURRENT_TIMESTAMP, (SELECT purchase_date FROM asset_management.assets WHERE asset_id=18)::timestamptz + interval '5 days'), NULL, 3, 'Issued'),
  (19, 3, LEAST(CURRENT_TIMESTAMP, (SELECT purchase_date FROM asset_management.assets WHERE asset_id=19)::timestamptz + interval '5 days'), NULL, 3, 'Issued'),
  (20, 4, LEAST(CURRENT_TIMESTAMP, (SELECT purchase_date FROM asset_management.assets WHERE asset_id=20)::timestamptz + interval '5 days'), NULL, 3, 'Issued'),
  (21, 5, LEAST(CURRENT_TIMESTAMP, (SELECT purchase_date FROM asset_management.assets WHERE asset_id=21)::timestamptz + interval '5 days'), NULL, 3, 'Issued'),
  (22, 6, LEAST(CURRENT_TIMESTAMP, (SELECT purchase_date FROM asset_management.assets WHERE asset_id=22)::timestamptz + interval '5 days'), NULL, 3, 'Issued'),
  (23, 7, LEAST(CURRENT_TIMESTAMP, (SELECT purchase_date FROM asset_management.assets WHERE asset_id=23)::timestamptz + interval '5 days'), NULL, 3, 'Issued'),
  (24, 8, LEAST(CURRENT_TIMESTAMP, (SELECT purchase_date FROM asset_management.assets WHERE asset_id=24)::timestamptz + interval '5 days'), NULL, 3, 'Issued'),
  (25, 9, LEAST(CURRENT_TIMESTAMP, (SELECT purchase_date FROM asset_management.assets WHERE asset_id=25)::timestamptz + interval '5 days'), NULL, 3, 'Issued'),
  (26, 10, LEAST(CURRENT_TIMESTAMP, (SELECT purchase_date FROM asset_management.assets WHERE asset_id=26)::timestamptz + interval '5 days'), NULL, 3, 'Issued'),
  (27, 1, LEAST(CURRENT_TIMESTAMP, (SELECT purchase_date FROM asset_management.assets WHERE asset_id=27)::timestamptz + interval '5 days'), NULL, 3, 'Issued'),
  (33, 2, LEAST(CURRENT_TIMESTAMP, (SELECT purchase_date FROM asset_management.assets WHERE asset_id=33)::timestamptz + interval '5 days'), NULL, 3, 'Issued'),
  (35, 3, LEAST(CURRENT_TIMESTAMP, (SELECT purchase_date FROM asset_management.assets WHERE asset_id=35)::timestamptz + interval '5 days'), NULL, 3, 'Issued'),
  (36, 4, LEAST(CURRENT_TIMESTAMP, (SELECT purchase_date FROM asset_management.assets WHERE asset_id=36)::timestamptz + interval '5 days'), NULL, 3, 'Issued'),
  (40, 5, LEAST(CURRENT_TIMESTAMP, (SELECT purchase_date FROM asset_management.assets WHERE asset_id=40)::timestamptz + interval '5 days'), NULL, 3, 'Issued'),
  (42, 6, LEAST(CURRENT_TIMESTAMP, (SELECT purchase_date FROM asset_management.assets WHERE asset_id=42)::timestamptz + interval '5 days'), NULL, 3, 'Issued'),
  (1, 8, CURRENT_TIMESTAMP - interval '200 days', CURRENT_TIMESTAMP - interval '90 days', 3, 'Returned in good condition'),
  (10, 9, CURRENT_TIMESTAMP - interval '200 days', CURRENT_TIMESTAMP - interval '90 days', 3, 'Returned in good condition'),
  (17, 10, CURRENT_TIMESTAMP - interval '200 days', CURRENT_TIMESTAMP - interval '90 days', 3, 'Returned in good condition'),
  (30, 1, CURRENT_TIMESTAMP - interval '200 days', CURRENT_TIMESTAMP - interval '90 days', 3, 'Returned in good condition');
INSERT INTO asset_management.asset_history (asset_id, action_type, old_value, new_value, user_id, changed_date)
SELECT asset_id, 'Registered', NULL, asset_no, 3, COALESCE(purchase_date::timestamptz, created_date) FROM asset_management.assets;
INSERT INTO asset_management.asset_history (asset_id, action_type, old_value, new_value, user_id, changed_date)
SELECT aa.asset_id, 'Assigned', NULL, u.first_name || ' ' || u.last_name, 3, aa.assigned_date
FROM asset_management.asset_assignments aa JOIN asset_management.users u ON u.user_id = aa.user_id;
INSERT INTO asset_management.asset_history (asset_id, action_type, old_value, new_value, user_id, changed_date)
SELECT aa.asset_id, 'Returned', u.first_name || ' ' || u.last_name, NULL, 3, aa.returned_date
FROM asset_management.asset_assignments aa JOIN asset_management.users u ON u.user_id = aa.user_id
WHERE aa.returned_date IS NOT NULL;
INSERT INTO asset_management.maintenance_records (asset_id, issue, reported_date, start_date, completion_date, status, cost, supplier_id, technician) VALUES
  (13, 'Battery swelling', (date_trunc('month', CURRENT_DATE) + interval '1 days'), (date_trunc('month', CURRENT_DATE) + interval '1 days'), NULL, 'Open', NULL, 1, 'Workshop'),
  (14, 'Screen flicker', (date_trunc('month', CURRENT_DATE) + interval '3 days'), (date_trunc('month', CURRENT_DATE) + interval '3 days'), NULL, 'In Progress', 1450, 2, 'Workshop'),
  (31, 'No display signal', (date_trunc('month', CURRENT_DATE) + interval '0 days'), (date_trunc('month', CURRENT_DATE) + interval '0 days'), NULL, 'Open', NULL, 3, 'Workshop'),
  (1, 'Keyboard replacement', (date_trunc('month', CURRENT_DATE) + interval '2 days'), (date_trunc('month', CURRENT_DATE) + interval '2 days'), (date_trunc('month', CURRENT_DATE) + interval '2 days') + interval '2 days', 'Completed', 2300, 1, 'Workshop'),
  (5, 'Hinge repair', (date_trunc('month', CURRENT_DATE - interval '1 month') + interval '12 days'), (date_trunc('month', CURRENT_DATE - interval '1 month') + interval '12 days'), (date_trunc('month', CURRENT_DATE - interval '1 month') + interval '12 days') + interval '2 days', 'Completed', 1850, 3, 'Workshop'),
  (8, 'Fan noise', (date_trunc('month', CURRENT_DATE - interval '1 month') + interval '20 days'), (date_trunc('month', CURRENT_DATE - interval '1 month') + interval '20 days'), (date_trunc('month', CURRENT_DATE - interval '1 month') + interval '20 days') + interval '2 days', 'Completed', 650, 1, 'Workshop'),
  (20, 'Dead pixels', (date_trunc('month', CURRENT_DATE - interval '1 month') + interval '8 days'), (date_trunc('month', CURRENT_DATE - interval '1 month') + interval '8 days'), (date_trunc('month', CURRENT_DATE - interval '1 month') + interval '8 days') + interval '2 days', 'Completed', 3900, 3, 'Workshop'),
  (11, 'SSD failure', (date_trunc('month', CURRENT_DATE - interval '1 month') + interval '15 days'), (date_trunc('month', CURRENT_DATE - interval '1 month') + interval '15 days'), (date_trunc('month', CURRENT_DATE - interval '1 month') + interval '15 days') + interval '2 days', 'Completed', 5200, 1, 'Workshop');
COMMIT;
