from dataclasses import dataclass

@dataclass(frozen=True)
class CurrentUser:
    id: int
    name: str
    department_id: int | None = None


class DemoIdentity:
    """Standalone identity for personal shortcuts; it does not restrict database access.

    The integrated system can replace this with its signed-in user's identity.
    """

    DEFAULT_EMAIL = "naledi.mokoena@example.co.za"

    def resolve(self, cursor, email: str | None = None) -> CurrentUser:
        email = (email or self.DEFAULT_EMAIL).lower()
        cursor.execute(
            """SELECT user_id, department_id, first_name || ' ' || last_name AS name
               FROM asset_management.users WHERE lower(email) = %s""",
            (email,),
        )
        row = cursor.fetchone()
        if row is None:
            return CurrentUser(id=0, name="Guest")
        return CurrentUser(row["user_id"], row["name"], row["department_id"])
