SELECT a.asset_no, a.description,
       to_char(aa.assigned_date AT TIME ZONE 'Africa/Johannesburg', 'DD Mon YYYY HH24:MI') AS assigned,
       COALESCE(to_char(aa.returned_date AT TIME ZONE 'Africa/Johannesburg', 'DD Mon YYYY HH24:MI'), 'Still assigned') AS returned,
       COALESCE(assigner.first_name || ' ' || assigner.last_name, '-') AS assigned_by,
       COALESCE(aa.return_condition, '-') AS return_condition,
       COUNT(*) OVER () AS total
FROM asset_management.asset_assignments aa
JOIN asset_management.assets a ON a.asset_id = aa.asset_id
JOIN asset_management.users holder ON holder.user_id = aa.user_id
LEFT JOIN asset_management.users assigner ON assigner.user_id = aa.assigned_by_user_id
WHERE aa.user_id = %(person_id)s
  AND (
    (%(assignment_mode)s = 'assigned'
      AND aa.assigned_date AT TIME ZONE 'Africa/Johannesburg' >= %(date_from)s::date
      AND aa.assigned_date AT TIME ZONE 'Africa/Johannesburg' < %(date_to)s::date + 1)
    OR (%(assignment_mode)s = 'returned'
      AND aa.returned_date IS NOT NULL
      AND aa.returned_date AT TIME ZONE 'Africa/Johannesburg' >= %(date_from)s::date
      AND aa.returned_date AT TIME ZONE 'Africa/Johannesburg' < %(date_to)s::date + 1)
    OR (%(assignment_mode)s = 'held'
      AND aa.assigned_date AT TIME ZONE 'Africa/Johannesburg' < %(date_to)s::date + 1
      AND (aa.returned_date IS NULL OR
           aa.returned_date AT TIME ZONE 'Africa/Johannesburg' > %(date_from)s::date))
    OR (%(assignment_mode)s = 'all_events'
      AND ((
        aa.assigned_date AT TIME ZONE 'Africa/Johannesburg' >= %(date_from)s::date
        AND aa.assigned_date AT TIME ZONE 'Africa/Johannesburg' < %(date_to)s::date + 1
      ) OR (
        aa.returned_date IS NOT NULL
        AND aa.returned_date AT TIME ZONE 'Africa/Johannesburg' >= %(date_from)s::date
        AND aa.returned_date AT TIME ZONE 'Africa/Johannesburg' < %(date_to)s::date + 1
      ))
    )
  )
ORDER BY aa.assigned_date DESC, a.asset_no
LIMIT %(row_limit)s