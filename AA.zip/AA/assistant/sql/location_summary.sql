,
filtered_assets AS (
    SELECT a.*
    FROM scoped a {{JOINS}}
    WHERE {{FILTERS}}
),
location_counts AS (
    SELECT l.location_id, l.name AS location, COUNT(a.asset_id)::int AS asset_count
    FROM asset_management.locations l
    LEFT JOIN filtered_assets a ON a.location_id = l.location_id
    GROUP BY l.location_id, l.name
),
summary AS (
    SELECT COUNT(*)::int AS registered_locations,
           COUNT(*) FILTER (WHERE asset_count > 0)::int AS locations_with_assets
    FROM location_counts
)
SELECT lc.location,
       lc.asset_count,
       summary.registered_locations,
       summary.locations_with_assets
FROM location_counts lc
CROSS JOIN summary
WHERE (%(location_mode)s <> 'occupied' OR lc.asset_count > 0)
ORDER BY lc.location
LIMIT %(row_limit)s