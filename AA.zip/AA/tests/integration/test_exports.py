"""Word and Excel downloads reuse supported, parameterized assistant questions."""


def test_excel_export_returns_a_workbook_with_a_report_filename(api):
    status, headers, body = api.export("Show all available laptops", "xlsx")
    assert status == 200
    assert headers["Content-Type"].startswith(
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    )
    assert headers["Content-Disposition"].endswith(".xlsx\"")
    assert body.startswith(b"PK")


def test_word_export_returns_a_document(api):
    status, headers, body = api.export("Show all available laptops", "docx")
    assert status == 200
    assert headers["Content-Type"].startswith(
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    )
    assert headers["Content-Disposition"].endswith(".docx\"")
    assert body.startswith(b"PK")


def test_export_rejects_an_unsupported_format(api):
    status, _, _ = api.export("Show all available laptops", "csv")
    assert status == 400