def test_location_count_reports_registered_and_occupied_locations(api, sql):
    reply = api.ask("How many locations do we have?")
    registered = sql("SELECT COUNT(*) FROM asset_management.locations")[0][0]
    occupied = sql(
        "SELECT COUNT(DISTINCT location_id) FROM asset_management.assets WHERE location_id IS NOT NULL"
    )[0][0]
    assert (reply["scope"], reply["intent"]) == ("in", "location_summary")
    assert f"**{registered} location" in reply["answer"]
    assert f"**{occupied} location" in reply["answer"]
    assert reply["table"] is not None
    assert {row["location"] for row in reply["table"]["rows"]} == {
        row[0] for row in sql("SELECT name FROM asset_management.locations")
    }


def test_location_list_only_shows_places_holding_assets(api, sql):
    reply = api.ask("List all the locations where we have assets")
    expected = sql(
        """SELECT l.name, COUNT(a.asset_id)
           FROM asset_management.locations l
           JOIN asset_management.assets a ON a.location_id = l.location_id
           GROUP BY l.location_id, l.name
           ORDER BY l.name"""
    )
    actual = [(row["location"], int(row["asset_count"])) for row in reply["table"]["rows"]]
    assert (reply["intent"], reply["slots"]["location_mode"]) == ("location_summary", "occupied")
    assert actual == expected