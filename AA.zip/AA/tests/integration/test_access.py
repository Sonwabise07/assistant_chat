import psycopg
import pytest

S = "asset_management."


def registered(reply: dict) -> int:
    return int(reply["answer"].split("**")[1].split()[0])


def test_shared_chatbot_scope_includes_all_assets(api, sql):
    reply = api.ask("How many assets are registered?")
    assert registered(reply) == sql(f"SELECT count(*) FROM {S}assets")[0][0]


def test_database_role_cannot_write(settings):
    with psycopg.connect(settings.database_url) as connection, pytest.raises(psycopg.errors.Error):
        connection.execute(f"DELETE FROM {S}assets")
