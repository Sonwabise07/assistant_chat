from assistant.catalog import load_catalog
from assistant.service import AssistantService
from assistant.understanding.social import classify_social
from assistant.vocabulary import load_vocabulary


def test_greetings_and_small_talk_have_friendly_social_replies():
    for question, expected in [
        ("Hi!", "greeting"),
        ("Hello there", "greeting"),
        ("Good morning.", "greeting"),
        ("How are you?", "small_talk"),
        ("Hi, how are you?", "small_talk"),
        ("Who are you?", "identity"),
        ("Thanks!", "thanks"),
        ("Goodbye", "goodbye"),
        ("What can you do?", "help"),
    ]:
        assert classify_social(question)[0] == expected


def test_social_matching_does_not_swallow_asset_questions():
    assert classify_social("Hi, how many assets do we have?") is None
    assert classify_social("Show me available laptops") is None


def test_greeting_returns_without_connecting_to_the_database():
    class DatabaseMustNotBeUsed:
        def cursor(self):
            raise AssertionError("Social replies should not query the database")

    service = AssistantService(
        catalog=load_catalog(),
        vocab=load_vocabulary(),
        database=DatabaseMustNotBeUsed(),
        identity=None,
        classifier=None,
        runner=None,
        dashboards=None,
        charts=None,
    )
    reply = service.ask("Hi")
    assert reply["scope"] == "social"
    assert reply["intent"] == "greeting"
    assert "Hi!" in reply["answer"]
    assert [chip["label"] for chip in reply["chips"]] == [
        "Count registered assets",
        "Browse dashboards",
    ]